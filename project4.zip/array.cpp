#include <iostream>
#include <string>
#include <cassert>

using namespace std;

//function declarations
int appendToAll(string a[], int n, string value);
int lookup(const string a[], int n, string value);
int positionOfMax(const string a[], int n);
int rotateLeft(string a[], int n, int pos);
int countRuns(const string a[], int n);
int flip(string a[], int n);
int differ(const string a1[], int n1, const string a2[], int n2);
int subsequence(const string a1[], int n1, const string a2[], int n2);
int lookupAny(const string a1[], int n1, const string a2[], int n2);
int split(string a[], int n, string splitter);
void quickSort(string a[], int start, int end);
void partition(string a[], int start, int end, int& partitionIndex);


int main() {
	return 0;
}

int appendToAll(string a[], int n, string value) {
	if (n < 0) return -1; //return -1 since number of elements can't be negative
	for (int i = 0; i < n; ++i) { //iterate through the array
		a[i] += value; //and append value to each element of the array
	}
	return n; 
}

int lookup(const string a[], int n, string value) {
	if (n <= 0) return -1; //return -1 if #elements is negative
	for (int i = 0; i < n; ++i) { //iterate through array
		if (a[i] == value) { //if element is equal to the target
			return i; //return the index of the element
		}
	}
	return -1; //return -1 if value isn't found 
}

int positionOfMax(const string a[], int n) {
	if (n <= 0) return -1; //return -1 if no elements are considered or negative #elements
	int largestIndex = 0; //initialize the largest index to the first one
	for (int i = 0; i < n; ++i) { //iterate through the array
		if (a[i] > a[largestIndex]) 
			largestIndex = i; //set the largest index to an current index if the current element is larger than the last biggest element 
	}
	return largestIndex; //return the largest index in the array
}

int rotateLeft(string a[], int n, int pos) {
	if (n < 0 || pos >= n || pos < 0) return -1; //return -1 if #elements is invalid or if position is out of bounds
	string temp = a[pos]; //store the position of the element to be moved to the end in a temporary variable
	for (int i = pos; i < n - 1; ++i) { 
		a[i] = a[i + 1]; //set elements in the array to be the element after it (shift left)
	}
	a[n - 1] = temp; //and move the temporary variable to the last position of the array
	return pos; //return initial position
}

int countRuns(const string a[], int n) {
	if (n < 0) return -1; //negative elements of interest, return 0
	else if (n == 0) return 0; //no runs if there are no elements of interest
	int count = 1; 
	for (int i = 0; i < n - 1; ++i) {
		if (a[i] != a[i + 1]) //if the current element doesn't equal next element, increment count (another sequence found)
			count++;
	}
	return count; //return count
}
 
int flip(string a[], int n) {
	if (n < 0) return -1;
	for (int i = 0; i < n/2; ++i) { //iterate through have of the array
		string temp = a[i]; //swap current element with corresponding element from other side of the array...
		a[i] = a[n - i - 1]; //suppose n = 5 then 1 and 5 get swapped, 2 and 4 get swapped, 3 and 3 get swapped
		a[n - i - 1] = temp;
	}
	return n; //return n
}

int differ(const string a1[], int n1, const string a2[], int n2) {
	if (n1 < 0 || n2 < 0) return -1; //if any of the #elements is negative, return -1
	int smaller = n1; //find the smaller #elements
	if (n2 < n1)
		smaller = n2;
	for (int i = 0; i < smaller; ++i) { //iterate through the array
		if (a1[i] != a2[i]) { //if current element isn't equal to current element of second array, return the current index
			return i;
		}
	}
	return smaller; //if no elements differ, return the smaller of the 2 element sizes
}

int subsequence(const string a1[], int n1, const string a2[], int n2) {
	if (n1 < 0 || n2 < 0) return -1; //if any of the #elements are less than 0, return -1
	if (n2 == 0) return 0; //all subsequences of length 0 can be matched to index 0
	int temp = 0, count = 0;
	for(int i = 0; i < n2; ++i) {
		for (int j = temp; j < n1; ++j) {
			if(a2[i] == a1[j]) {
				temp = (j + 1); //increment the starting point of the search of the first array...essentially if a match is made, increase both i and j to try to match their next elements
				count++; //increment number of matched strings
				if (count == n2) //if the number of matched strings is equal to the #elements in the second array, 
					return j - count + 1; //return the position of the first matched string
				break; //break out of inner loop
			}
			else 
				count = 0; //set count to 0 again
			temp++; //increment the next index of the inner loop
		}
	}
	return -1;
}

int lookupAny(const string a1[], int n1, const string a2[], int n2) {
	if (n1 <= 0 || n2 <= 0) return -1; //can't look up elements if #elements is 0 or negative
	for (int i = 0; i < n1; ++i) { 
		for (int j = 0; j < n2; ++j) {
			if (a1[i] == a2[j]) //if a match is found, return the current index of the first array
				return i;
		}
	}
	return -1; //target not found
}

int split(string a[], int n, string splitter) {
	if (n < 0) return -1; //can't split if element size is 0
	quickSort(a, 0, n - 1); //sort the array so that the first index whos corrseponding element is equal to or greater than splitter is returned
	for (int i = 0; i < n; ++i) { //iterate through the sorted array
		if (a[i] >= splitter) return i; //return the index that is >= splitter
	}
	return n; //if no element is >= splitter return the number of elements considered
}

//function for implementing the quicksort algorithm
void quickSort(string a[], int start, int end) {
	if (start >= end) return; //stop once the leftIndex is greater than the right index
	int partitionIndex; 
	partition(a, start, end, partitionIndex); //partition the array into 2 parts
	quickSort(a, start, partitionIndex - 1); //recursively (divide and conquer) sort the array from start to middle
	quickSort(a, partitionIndex + 1, end); //from middle to end
}

void partition(string a[], int start, int end, int& partitionIndex) {
	string pivot = a[end]; //choose last element to be the pivot
	partitionIndex = start; //partition index is initalized to the first index
	for (int i = start; i < end; ++i) { //iterate through the array
		if (a[i] <= a[end]) { 
			string temp = a[i]; //swap the element with the element corresponding to the partition index
			a[i] = a[partitionIndex];
			a[partitionIndex] = temp;
			partitionIndex++;
		}
	}
	string temp = a[end]; //swap the last element with the element corresponding to the partition index
	a[end] = a[partitionIndex];
	a[partitionIndex] = temp;
}