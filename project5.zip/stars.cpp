#define _CRT_SECURE_NO_DEPRECATE

#include <iostream>
#include "utilities.h"
#include <cstring>

using namespace std;

const char WORD_FILE[] = "words.txt";
const int MAX_WORDS = 9000;

//function prototypes
int runOneRound(const char words[][MAXWORDLEN + 1], int nWords, int wordnum);
void quickSort(char words[][MAXWORDLEN + 1], int start, int end);
void partition(char words[][MAXWORDLEN + 1], int start, int end, int& partitionIndex);
bool found(const char words[][MAXWORDLEN + 1], int start, int end, char target[]);

int main() {
	char words[MAX_WORDS][MAXWORDLEN + 1]; //declare an array of cstrings of at least 9000 words each 7 characters long
	
	int nWords = getWords(words, 1000, WORD_FILE); //read the words from a file into the array and store the number of words in nWOrds
	if (nWords < 1) { //error checking...can't play the game if there is less than 1 word
		cout << "No words were loaded, so I can't play the game";
		return 0;
	}

	cout << "How many rounds do you want to play? "; //prompt the user
	int n_rounds; cin >> n_rounds; //read the number of rounds in
	if (n_rounds < 0) { //error checking...can't play the game if the user doesn't wanna play
		cout << "The number of rounds must be positive" << endl;
		return 0;
	}
	cin.ignore(10000, '\n'); //since we just read into an int we have to clear the input buffer so we can read the probe words from the user

	//quickSort(words, 1, nWords - 1); //sort the array of cstrings

	int currentRound = 0; //holds the current round the player is on
	int random = randInt(0, nWords - 1); //stores a random integer 
	char secretWord[MAXWORDLEN + 1]; //holds the value of the target string
	strcpy(secretWord, words[random]); //and stores the string at the random position into the secret word

	int minScore = 100000000, maxScore = 0; //create variables to hold the best and worst scores
	double total = 0; //holds the total score for all the rounds the user has played
	while (currentRound < n_rounds) { //loop through the number of rounds the user wants to play
		currentRound++; //increase the current round
		cout << "\n"; //formating stuff
		cout << "Round " << currentRound << endl;
		cout << "The secret word is " << strlen(secretWord) << " letters long.\n"; //print how many characters are in the target word

		int score = runOneRound(words, nWords, random); //get the score for one round
		if (score == -1) return 0; //if there was something wrong...terminate the program
		
		if (score == 1)
			cout << "You got it in 1 try.\n"; //print results
		else
			cout << "You got it in " << score << " tries.\n";

		//update the best and worst scores
		if (score > maxScore) 
			maxScore = score; 
		if (score < minScore)
			minScore = score;

		total += score; //add the score for the round to the total score
		double average = total / currentRound; //compute the average score
		cout.setf(ios::fixed); //more formatting stuff
		cout.precision(2); 
		cout << "Average: " << average << ", minimum: " << minScore << ", maximum: " << maxScore << endl; //print out the stats
	}
	return 0;
}

int runOneRound(const char words[][MAXWORDLEN + 1], int nWords, int wordnum) {
	if (nWords <= 0 || wordnum >= nWords || wordnum < 0) return -1; //bad arguments
	char secretWord[MAXWORDLEN + 1]; //create a cstring for holding the secret word

	const char MAX_PROBE_SIZE = 100; //maximum number of characters in the probe word allowed
	int score = 1; //start score off at 1 
	bool guessed = false; //flag for whether or not the probe word is the target word

	while (!guessed) { //loop until the user has guessed the word
		strcpy(secretWord, words[wordnum]); //copy the target to the secretWord...we need to do this to reset the secret word to its default value since we make changes to it later on

		cout << "Probe word: ";
		char probeWord[MAX_PROBE_SIZE]; //create a cstring for storing the probe word entered
		cin.getline(probeWord, MAX_PROBE_SIZE - 1); //read into the probe word
		if (strlen(probeWord) < MINWORDLEN || strlen(probeWord) > MAXWORDLEN) { //invalid number of characters so go to next iteration of the loop
			cout << "Your probe word must be a word of 4 to 6 lower case letters.\n"; //and prompt the user
			continue;
		}

		bool badSyntax = false; //there are some uppercase characters
		for (int i = 0; probeWord[i] != '\0'; ++i) {
			if (!islower(probeWord[i])) { //if a character is not lower cased, then set the flag to true
				cout << "Your probe word must be a word of 4 to 6 lower case letters.\n";
				badSyntax = true;
				break; 
			}
		}
		if (badSyntax)
			continue; //go to next iteration of the loop if the probe word has uppercase characters

		bool found = false;  
		for (int i = 0; i < nWords; ++i) { //do a linear search
			if (strcmp(probeWord, words[i]) == 0) {
				found = true;
				break;
			}
		}
		if (!found) {
			cout << "I don't know that word.\n"; //didn't find the probe word
			continue;
		}
		/*
		if (!found(words, 0, nWords - 1, probeWord)) { //if the probeWord isn't in the array of cstrings then go to to next iteration of the loop
			cout << "I don't know that word.\n";
			continue;
		}*/

		if (strcmp(secretWord, probeWord) == 0) { //the probe word matches the secret word, then set the flag guessed to true
			guessed = true;
		} 
		else { //if it doesn't match...we know that if the code gets here, the probe word has valid syntax and the word is in the array.Thus it's a valid probe
			int nStars = 0, nPlanets = 0; //create variables that hold the number of stars and planets
			for (int i = 0; secretWord[i] != '\0'; ++i) { //do character comparison
				for (int j = 0; probeWord[j] != '\0'; ++j) {
					if ((secretWord[i] == probeWord[j]) && (i == j)) { //if the characters at the current positions are the same and the 2 positions are the same
						nStars++; //...we have found a star
						secretWord[i] = '0'; //and change the current characters to some garbage value that won't be in a word
						probeWord[j] = '1';
					}
				}
			}
			for (int i = 0; secretWord[i] != '\0'; ++i) { //search for planets
				for (int j = 0; probeWord[j] != '\0'; ++j) {
					if (secretWord[i] == probeWord[j] && i != j) {
						nPlanets++; //found a planet
						secretWord[i] = '2'; //change characters to garbage values
						probeWord[j] = '3';
 					}
				}
			}

			cout << "Stars: " << nStars << ", Planets: " << nPlanets << endl; //print the number of stars and planets 
			score++; //and increase the score because the target wasn't found
		}
	}
	return score; //once the target has been guessed, return the score for that round
}

void quickSort(char words[][MAXWORDLEN + 1], int start, int end) { //quick sort algorithm
	if (start >= end) return; //stop once the leftIndex is greater than the right index
	int partitionIndex;
	partition(words, start, end, partitionIndex); //partition the array into 2 parts
	quickSort(words, start, partitionIndex - 1); //recursively (divide and conquer) sort the array from start to middle
	quickSort(words, partitionIndex + 1, end); //...and from middle to end
}

void partition(char words[][MAXWORDLEN + 1], int start, int end, int& partitionIndex) {
	char pivot[MAXWORDLEN + 1]; //choose last element to be the pivot
	strcpy(pivot, words[end]);
	partitionIndex = start; //partition index is initalized to the first index
	for (int i = start; i < end; ++i) { //iterate through the array
		if (strcmp(words[i], words[end]) < 0) {
			char temp[MAXWORDLEN + 1];
			strcpy(temp, words[i]); //swap the element with the element corresponding to the partition index
			strcpy(words[i], words[partitionIndex]);
			strcpy(words[partitionIndex], temp);
			partitionIndex++;
		}
	}
	char temp[MAXWORDLEN + 1]; //perform one final swap
	strcpy(temp, words[end]);
	strcpy(words[end], words[partitionIndex]);
	strcpy(words[partitionIndex], temp);
}

bool found(const char words[][MAXWORDLEN + 1], int start, int end, char target[]) { //binary search for determining if probe is in the array
	while (start <= end) { 
		int middle = (start + end) / 2; //choose middle elment to be target
		if (strcmp(words[middle], target) == 0) {
			return true; //found a match so return true
		}
		else if (strcmp(words[middle], target) < 0)
			start = middle + 1;
		else
			end = middle - 1;
	}
	return false; //word wasn't found in the array so return
}
