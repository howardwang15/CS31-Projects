#include <iostream>
#include <string>
#include <cctype>
#include <cassert>

using namespace std;

//helper functions for solving the problem
void resetVariables(int& octave, char& accidental, bool& singleNote);
bool validNotes(string song);
bool validBeats(string song);
bool hasCorrectSyntax(string song);
int encodeSong(string song, string& instructions, int& badBeat);
char encodeNote(int octave, char noteLetter, char accidentalSign);

int main() {
	//empty main??? What??? it's gucci
	return 0;
}

//determine if the string has valid characters
bool validNotes(string song) {
	for (int i = 0; i < song.length(); ++i) {
		//if the characters are not between A and G (ASCII values) or any of the accidentals or digits or/ then return false since there are 
		//invalid characters
		if ((song[i] > 'G' && song[i] != 'b') || (song[i] < 'A' && song[i] != '#' && song[i] != '/' && !isdigit(song[i]))) 
			return false;
	}
	return true;
}

//returns if the last character is a slash to test if the beat is well formed or if the beat is empty
bool validBeats(string song) {
	return song.length() == 0 || song[song.length() - 1] == '/';
}

bool hasCorrectSyntax(string song) {
	if (!validNotes(song) || !validBeats(song)) return false; //if beat is not well formed or if characters are invalid, return false immediatly
	bool nextCanBeAccidental = false; //flags for determining whether the next character can be an accidental or octave number
	bool nextCanBeOctave = false;
	int begIndex = 0; //the beginning index for extracting a beat substring
	for (int i = 0; i < song.length(); ++i) { //iterate through the length of the string
		if (song[i] == '/') { //we know we have just read a beat
			string beat = song.substr(begIndex, i - begIndex + 1); //extract the beat as a substring
			if (!isalpha(song[begIndex]) && song[begIndex] != '/') { //see if the first element of the extracted beat is a letter or 
				return false;										 //slash (empty beat). if not, return false since one of the two must apply
			}
			begIndex = i + 1; //increase the starting index of the beat to the beginning of the next beat
			for (int j = 0; j < beat.length(); ++j) {	//iterate through the beat	
				if (isalpha(beat[j]) && beat[j] != 'b') { //if the character is a note letter, then we know the next character can be an acc. or octave
					nextCanBeAccidental = true;
					nextCanBeOctave = true;
				}
				else if ((beat[j] == '#' || beat[j] == 'b') && nextCanBeAccidental) { //if the accidental is in a valid pos. then the next 
					nextCanBeAccidental = false;									  //character can't be an accidental
				}
				else if (isdigit(beat[j]) && nextCanBeOctave) {	//if the octave is in a valid pos, then the next character has to be a slash or 
					nextCanBeAccidental = false;				//letter so set both flags to be false
					nextCanBeOctave = false;
				}
				else if (beat[j] == '/') { //debugging stuff
					cerr << "end of beat\n";
				}
				else {
					return false; //if the current character doesn't meet any of the above requirements, it is invalid and we can say
								  //that the string is not syntatically correct
				}
			}
		}
	}
	return true; //if every character is fine, then string is a song string
}

//reset some variables to (un)default values
void resetVariables(int& octave, char& accidental, bool& singleNote) {
	octave = 4;
	accidental = ' ';
	singleNote = false;
}

int encodeSong(string song, string& instructions, int& badBeat) {
	if (!hasCorrectSyntax(song)) return 1; //do correct syntax check first so instr. and bb don't have to be changed
	string tempInstructions = instructions; //store whatever value instr. is initialized w/ to a temp variable 
	instructions.clear(); //empty the instructions string so we can append to an empty one
	int begIndex = 0; //same as hasCorrectSyntax()
	int beatNumber = 0; //beat counter
	char accidental = ' '; //default values for accidental and octave
	char noteLetter;
	int octave = 4;
	for (int i = 0; i < song.length(); ++i) { //iterate through the song string
		if (song[i] == '/') {
			beatNumber++; //found a beat so increase the current beat number 
			cerr << "beatNumber: " << beatNumber << endl; //debugging purposes
			string beat = song.substr(begIndex, i - begIndex + 1);  //extract beat from the song string
			string encodedBeat = ""; //string that stores the encoded beat
			if (beat.length() == 1) { //beat can be length 1 if it is just a slash...in this case append a space to the instr. and move on
				instructions += ' ';
				begIndex = i + 1;
				continue;
			}
			begIndex = i + 1; //move the starting index to the starting position of the next beat
			bool onlyOneNote = true; //flag for whether or not the beat consists of one note
			bool isChord = false; //flag for whether or not the beat has a chord
			for (int j = 0; j < beat.length(); j++) { //iterate through the beat
				if (isalpha(beat[j]) && beat[j] != 'b') { //if the current character is a note letter
					if (!onlyOneNote) { //we have reached another character of the same beat so we know we have a chord
						isChord = true;
						encodedBeat += encodeNote(octave, noteLetter, accidental); //append the current encoded note to the encoded beat
						//cout << "instructions: " << notes << endl;
					}
					resetVariables(octave, accidental, onlyOneNote); //set variables to (un)default values
					noteLetter = beat[j]; //store note letter
				}
				else if ((beat[j] == '#' || beat[j] == 'b')) {
					accidental = beat[j]; //store accidental
				}
				else if (isdigit(beat[j])) {
					octave = beat[j] - '0'; //get int form of a character digit
					if (octave < 1 || octave > 6) { //invalid unplayable octaves
						badBeat = beatNumber; //set badbeat to the current beatnumber and set instr. back to its original value and return 2
						instructions = tempInstructions;
						return 2;
					}
				}
				else if (beat[j] == '/') { //reached the end of the beat
					if (encodeNote(octave, noteLetter, accidental) == ' ') {//out of bounds error so the beat was bad
						badBeat = beatNumber;
						return 2;
					}
					encodedBeat += encodeNote(octave, noteLetter, accidental); //append the last encoded note to the encoded beat
				}
			}
			if (isChord) {
				encodedBeat = "[" + encodedBeat + "]"; //append brackets around the beat if it is a chord
			}
			cerr << "incrementing beatnumber\n";
			instructions += encodedBeat; //append the encodedbeat to instructions
		}
	}
	return 0; //if runction reaches this point, the song string is playable
}


//*************************************
//  encodeNote
//*************************************

// Given an octave number, a note letter, and an accidental sign, return
// the character that the indicated note is encoded as if it is playable.
// Return a space character if it is not playable.
//
// First parameter:   the octave number (the integer 4 is the number of the
//                    octave that starts with middle C, for example).
// Second parameter:  an upper case note letter, 'A' through 'G'
// Third parameter:   '#', 'b', or ' ' (meaning no accidental sign)
//
// Examples:  encodeNote(4, 'A', ' ') returns 'Q'
//            encodeNote(4, 'A', '#') returns '%'
//            encodeNote(4, 'H', ' ') returns ' '

char encodeNote(int octave, char noteLetter, char accidentalSign)
{
	// This check is here solely to report a common CS 31 student error.
	if (octave > 9)
	{
		cerr << "********** encodeNote was called with first argument = "
			<< octave << endl;
	}

	// Convert Cb, C, C#/Db, D, D#/Eb, ..., B, B#
	//      to -1, 0,   1,   2,   3, ...,  11, 12

	int note;
	switch (noteLetter)
	{
	case 'C':  note = 0; break;
	case 'D':  note = 2; break;
	case 'E':  note = 4; break;
	case 'F':  note = 5; break;
	case 'G':  note = 7; break;
	case 'A':  note = 9; break;
	case 'B':  note = 11; break;
	default:   return ' ';
	}
	switch (accidentalSign)
	{
	case '#':  note++; break;
	case 'b':  note--; break;
	case ' ':  break;
	default:   return ' ';
	}

	// Convert ..., A#1, B1, C2, C#2, D2, ... to
	//         ..., -2,  -1, 0,   1,  2, ...

	int sequenceNumber = 12 * (octave - 2) + note;

	string keymap = "Z1X2CV3B4N5M,6.7/A8S9D0FG!H@JK#L$Q%WE^R&TY*U(I)OP";
	if (sequenceNumber < 0 || sequenceNumber >= keymap.size())
		return ' ';
	return keymap[sequenceNumber];
}

