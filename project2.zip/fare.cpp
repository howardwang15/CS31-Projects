#include <iostream>
#include <string>

using namespace std;

const int LINE_LENGTH = 10000; //defines the max number of chars for cin.ignore to handle

int main() {
	//get the age of rider and does error checking for invalid input
	cout << "Age of rider: ";
	int age; cin >> age;
	if (age < 0) {
		cout << "---\n";
		cout << "The age must not be negative\n";
		return 1;
	}

	//gets whether of not the rider is a student and handles invalid input

	cout << "Student? (y/n): ";
	string isStudent; cin >> isStudent;
	if (isStudent != "y" && isStudent != "n") {
		cout << "---\n";
		cout << "You must enter y or n\n";
		return 1;
	}
	cin.ignore(LINE_LENGTH, '\n'); //use cin.ignore because cin is used before the following getline

	//get the destination of the rider and handles empty input
	cout << "Destination: ";
	string destination; getline(cin, destination);
	if (destination == "") {
		cout << "---\n";
		cout << "You must enter a destination\n";
		return 1;
	}

	//gets the number of time zones the rider crossed and handles bad input
	cout << "Number of zone boundaries crossed: ";
	int n_zones; cin >> n_zones;
	if (n_zones < 0) {
		cout << "---\n";
		cout << "The number of zone boundaries crossed must not be negative\n";
	}

	//variables for storing prices (defaults to 1.35 as the fixed amount and 0.55 for crossing every time zone)
	double fixedAmt = 1.35;
	double zonePrice = 0.55;
	double fare;	

	//if the rider is a senior
	if (age >= 65) {
		if (n_zones == 0) { //special discount for crossing no time zones
			fare = 0.45;
		}
		else if (n_zones == 1 && isStudent == "y") {
			fare = 0.65; //senior would choose the price students pay
		}
		else {
			fixedAmt = 0.55;
			zonePrice = 0.25;
			fare = fixedAmt + n_zones * zonePrice; //default discount
		}
	}
	else if (age < 18 && n_zones < 2) //discount for minors who cross 0 or 1 time zones
		fare = 0.65;
	else if (age >= 18 && isStudent == "y" && n_zones < 2) //discount for adult who's a student who crosses 0 or 1 time zone
		fare = 0.65;	
	else {	
		fare = fixedAmt + n_zones * zonePrice; //no discount applies so use the default fixed amount and price for crossing time zones
	}

	cout << "---\n";
	cout.setf(ios::fixed); //formats the fare
	cout.precision(2);
	cout << "The fare to " << destination << " is $" << fare << endl; //final calculation
}
